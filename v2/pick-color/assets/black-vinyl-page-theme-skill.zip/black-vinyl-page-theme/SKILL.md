---
name: black-vinyl-page-theme
description: Generate NetEase Cloud Music black vinyl page background gradients from an image D dominant color. Use when a user asks for black vinyl page color rules, music player page theme generation, D 主色 to gradient conversion, Figma gradient parameters, CSS tokens, or an AI workflow skill that turns cover-image palette results into top and bottom gradient colors.
---

# Black Vinyl Page Theme

## Overview

Use this skill to convert one cover-image D dominant color into the standardized black vinyl page gradient. The rule keeps H unchanged, adjusts only S and L by the agreed lightness intervals, and returns top color, bottom color, CSS tokens, Figma `GradientPaint`, and a short explanation.

## Workflow

1. Get the source color from the image palette result.
   - Prefer `D.no_filter` from the compact DTBLR result.
   - Fallback to `D.with_filter`.
   - Support legacy `dominate.no_filter`, `dominate.with_filter`, and `palette_16[0]`.
2. Convert the source color to HSL.
3. Keep H unchanged.
4. Adjust S by the L interval saturation rule.
5. Compute top and bottom L by the L interval background rule.
6. Return:
   - `gradient.top.hex`
   - `gradient.bottom.hex`
   - `tokens.backgroundGradient`
   - `figmaPaint`
   - `css`
   - `explanation`

## Quick Start

Run the bundled deterministic script:

```bash
node scripts/black-vinyl-theme.mjs '#4C4C4D'
```

Or pass JSON:

```bash
echo '{"dominantColor":"#4C4C4D"}' | node scripts/black-vinyl-theme.mjs
```

Pass the compact output from the image color picker Skill directly:

```bash
echo '{"D":{"no_filter":"#283048","with_filter":"#283048"}}' | node scripts/black-vinyl-theme.mjs
```

The script also accepts a full legacy picker result:

```json
{
  "dominate": {
    "no_filter": { "hex": "#4C4C4D", "hsl": { "h": 240, "s": 1, "l": 30 } },
    "with_filter": { "hex": "#4C4C4D", "hsl": { "h": 240, "s": 1, "l": 30 } }
  },
  "palette_16": []
}
```

The script also accepts service-like payloads such as `main.dominantColorHex`.

## Rule Summary

Source color:

```text
base = D.no_filter || D.with_filter || palette_16[0]
```

Hue:

```text
newH = originalH
```

Saturation:

```text
L=0:         newS = 0
1<=L<=4:    newS = S / (((100-L)/L)*0.5)
5<=L<=14:   newS = S / ((abs(L-50)*abs(L-50)/800*1) - L/100)
15<=L<=19:  newS = S / (abs(L-50)*abs(L-50)/800*1)
20<=L<=70:  newS = S / 1
71<=L<=95:  newS = S / (abs(L-50)*abs(L-50)/800*2)
96<=L<=99:  newS = S / ((L/(100-L))*0.5)
L=100:       newS = 0
```

Lightness:

```text
L<=19:
  topL = 0.2*L + 18 + L/100; if topL > 20 then topL -= 1
  bottomL = 0.1*L + 8 + L/100

20<=L<=70:
  topL = 0.1*L + 30; if topL > 35 then topL -= 1; if topL > L then topL = L
  bottomL = 0.1*L + 10

L>=71:
  topL = 0.2*L + 20 + L/100
  bottomL = 0.1*L + 10 + L/100
```

Round S/L to integers and clamp to `0-100`.

## Figma Usage

For Figma plugin integration, apply the returned `figmaPaint` to selected layers:

```js
figma.currentPage.selection[0].fills = [result.figmaPaint];
```

Plain browser clipboard cannot reliably write Figma's private fill-property clipboard format. If the user needs one-click application to a selected Figma layer, implement a Figma plugin that consumes this skill output.

## References

- Read `references/io-schema.json` when integrating this skill into a workflow or service.
- Read `references/rules.md` when checking or modifying the S/L formulas.
