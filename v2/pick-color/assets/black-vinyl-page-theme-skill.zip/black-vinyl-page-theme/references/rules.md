# Black Vinyl Page Theme Rules

## Source Priority

Use `D.no_filter` first. If it is missing, use `D.with_filter`. If both are missing, use `palette_16[0]`.

## HSL Adjustment

H is unchanged. Only S and L are adjusted.

### Saturation

| Original L | New S |
| --- | --- |
| `L=0` | `0` |
| `1<=L<=4` | `S / (((100-L)/L)*0.5)` |
| `5<=L<=14` | `S / ((abs(L-50)*abs(L-50)/800*1) - L/100)` |
| `15<=L<=19` | `S / (abs(L-50)*abs(L-50)/800*1)` |
| `20<=L<=70` | `S / 1` |
| `71<=L<=95` | `S / (abs(L-50)*abs(L-50)/800*2)` |
| `96<=L<=99` | `S / ((L/(100-L))*0.5)` |
| `L=100` | `0` |

### Lightness

For `L<=19`:

```text
topL = 0.2*L + 18 + L/100
if topL > 20 then topL = topL - 1
bottomL = 0.1*L + 8 + L/100
```

For `20<=L<=70`:

```text
topL = 0.1*L + 30
if topL > 35 then topL = topL - 1
if topL > L then topL = L
bottomL = 0.1*L + 10
```

For `L>=71`:

```text
topL = 0.2*L + 20 + L/100
bottomL = 0.1*L + 10 + L/100
```

Round final S/L to integers and clamp to `0-100`.
