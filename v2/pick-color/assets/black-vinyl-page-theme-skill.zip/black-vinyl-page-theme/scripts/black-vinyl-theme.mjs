#!/usr/bin/env node

const VERSION = '0.2.0';
const SKILL_CODE = 'BLACK_VINYL_PAGE_THEME';

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function round(n) {
  return Math.round(n);
}

function normalizeHex(input) {
  if (typeof input !== 'string') return null;
  const value = input.trim().replace(/^#/, '');
  if (/^[0-9a-f]{3}$/i.test(value)) {
    return `#${value.split('').map((char) => char + char).join('').toUpperCase()}`;
  }
  if (/^[0-9a-f]{6}$/i.test(value)) {
    return `#${value.toUpperCase()}`;
  }
  return null;
}

function hexToRgb(hex) {
  const normalized = normalizeHex(hex);
  if (!normalized) return null;
  return {
    r: parseInt(normalized.slice(1, 3), 16),
    g: parseInt(normalized.slice(3, 5), 16),
    b: parseInt(normalized.slice(5, 7), 16),
  };
}

function rgbToHsl(r, g, b) {
  const rr = clamp(r, 0, 255) / 255;
  const gg = clamp(g, 0, 255) / 255;
  const bb = clamp(b, 0, 255) / 255;
  const max = Math.max(rr, gg, bb);
  const min = Math.min(rr, gg, bb);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === rr) h = (gg - bb) / d + (gg < bb ? 6 : 0);
    else if (max === gg) h = (bb - rr) / d + 2;
    else h = (rr - gg) / d + 4;
    h *= 60;
  }

  return {
    h: round(h),
    s: round(s * 100),
    l: round(l * 100),
  };
}

function hexToHsl(hex) {
  const rgb = hexToRgb(hex);
  if (!rgb) return null;
  return {
    hex: normalizeHex(hex),
    ...rgbToHsl(rgb.r, rgb.g, rgb.b),
  };
}

function hslToHex(h, s, l) {
  const hue = (((h % 360) + 360) % 360) / 360;
  const sat = clamp(s, 0, 100) / 100;
  const light = clamp(l, 0, 100) / 100;

  if (sat === 0) {
    const v = round(light * 255);
    return `#${v.toString(16).padStart(2, '0').repeat(3).toUpperCase()}`;
  }

  const q = light < 0.5 ? light * (1 + sat) : light + sat - light * sat;
  const p = 2 * light - q;
  const channel = (t0) => {
    let t = t0;
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };

  const r = round(channel(hue + 1 / 3) * 255);
  const g = round(channel(hue) * 255);
  const b = round(channel(hue - 1 / 3) * 255);
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase()}`;
}

function hslCss(h, s, l) {
  return `hsl(${round(h)} ${round(s)}% ${round(l)}%)`;
}

function colorToken(h, s, l) {
  const hh = round((((h % 360) + 360) % 360));
  const ss = clamp(round(s), 0, 100);
  const ll = clamp(round(l), 0, 100);
  return {
    hex: hslToHex(hh, ss, ll),
    hsl: hslCss(hh, ss, ll),
    h: hh,
    s: ss,
    l: ll,
  };
}

function saturationRule(l) {
  if (l <= 0) {
    return { divisor: 0, range: 'L=0', formula: '新S = 0', note: 'L=0 时按规则将 S 归零。' };
  }
  if (l <= 4) {
    return {
      divisor: ((100 - l) / l) * 0.5,
      range: '1<=L<=4',
      formula: '新S = 原S ÷ ((100 - 原L) ÷ 原L × 0.5)',
      note: '极暗色按表格倍数降低 S，避免暗部颜色过脏。',
    };
  }
  if (l <= 14) {
    return {
      divisor: ((Math.abs(l - 50) * Math.abs(l - 50)) / 800) * 1 - l / 100,
      range: '5<=L<=14',
      formula: '新S = 原S ÷ (|原L - 50| × |原L - 50| ÷ 800 × 1 - 原L / 100)',
      note: '暗色区按二次曲线倍数调整 S；这里按正常运算优先级执行，不额外加括号。',
    };
  }
  if (l <= 19) {
    return {
      divisor: (Math.abs(l - 50) * Math.abs(l - 50)) / 800,
      range: '15<=L<=19',
      formula: '新S = 原S ÷ (|原L - 50| × |原L - 50| ÷ 800 × 1)',
      note: '低亮度区继续按二次曲线倍数调整 S。',
    };
  }
  if (l <= 70) {
    return {
      divisor: 1,
      range: '20<=L<=70',
      formula: '新S = 原S ÷ 1',
      note: '中间亮度区 S 保持不变，主要调整背景明度。',
    };
  }
  if (l <= 95) {
    return {
      divisor: ((Math.abs(l - 50) * Math.abs(l - 50)) / 800) * 2,
      range: '71<=L<=95',
      formula: '新S = 原S ÷ (|原L - 50| × |原L - 50| ÷ 800 × 2)',
      note: '高亮区按表格倍数降低 S，把浅色封面压回黑胶页可用范围。',
    };
  }
  if (l < 100) {
    return {
      divisor: (l / (100 - l)) * 0.5,
      range: '96<=L<=99',
      formula: '新S = 原S ÷ (原L ÷ (100 - 原L) × 0.5)',
      note: '接近白色时继续降低 S，避免白场偏色过强。',
    };
  }
  return { divisor: 0, range: 'L=100', formula: '新S = 0', note: 'L=100 时按规则将 S 归零。' };
}

function backgroundLightnessRule(l) {
  if (l <= 19) {
    let topL = 0.2 * l + 18 + l / 100;
    if (topL > 20) topL -= 1;
    return {
      topL,
      bottomL: 0.1 * l + 8 + l / 100,
      topFormula: '顶点新L = 0.2 × 原L + 18 + 原L ÷ 100；若新L > 20，则新L - 1',
      bottomFormula: '底点新L = 0.1 × 原L + 8 + 原L ÷ 100',
      note: '低亮度区使用暗部公式，顶部略亮、底部更暗，保证黑胶页层次。',
    };
  }
  if (l <= 70) {
    let topL = 0.1 * l + 30;
    if (topL > 35) topL -= 1;
    if (topL > l) topL = l;
    return {
      topL,
      bottomL: 0.1 * l + 10,
      topFormula: '顶点新L = 0.1 × 原L + 30；若新L > 35，则新L - 1；若新L > 原L，则取原L',
      bottomFormula: '底点新L = 0.1 × 原L + 10',
      note: '中间亮度区顶部 L 受原始 L 限制，避免背景比主色更亮。',
    };
  }
  return {
    topL: 0.2 * l + 20 + l / 100,
    bottomL: 0.1 * l + 10 + l / 100,
    topFormula: '顶点新L = 0.2 × 原L + 20 + 原L ÷ 100',
    bottomFormula: '底点新L = 0.1 × 原L + 10 + 原L ÷ 100',
    note: '高亮区使用高亮公式，把浅色封面压回黑胶页可用的深色渐变。',
  };
}

function adjustedS(rawS, rule) {
  if (rule.divisor === 0) return 0;
  return clamp(round(rawS / rule.divisor), 0, 100);
}

function hexToFigmaColor(hex) {
  const rgb = hexToRgb(hex);
  if (!rgb) throw new Error(`Invalid hex color: ${hex}`);
  return {
    r: Number((rgb.r / 255).toFixed(4)),
    g: Number((rgb.g / 255).toFixed(4)),
    b: Number((rgb.b / 255).toFixed(4)),
    a: 1,
  };
}

function createFigmaPaint(topHex, bottomHex) {
  return {
    type: 'GRADIENT_LINEAR',
    gradientTransform: [
      [0, 1, 0],
      [-1, 0, 1],
    ],
    gradientStops: [
      { position: 0, color: hexToFigmaColor(topHex) },
      { position: 1, color: hexToFigmaColor(bottomHex) },
    ],
  };
}

function cssText(theme) {
  return [
    ':root {',
    `  --vinyl-bg-top: ${theme.tokens.bgTop};`,
    `  --vinyl-bg-bottom: ${theme.tokens.bgBottom};`,
    `  --vinyl-bg-top-hsl: ${theme.tokens.bgTopHsl};`,
    `  --vinyl-bg-bottom-hsl: ${theme.tokens.bgBottomHsl};`,
    `  --vinyl-accent: ${theme.tokens.accent};`,
    `  --vinyl-button-fill: ${theme.tokens.buttonFill};`,
    `  --vinyl-button-text: ${theme.tokens.buttonText};`,
    `  --vinyl-text-primary: ${theme.tokens.textPrimary};`,
    `  --vinyl-text-secondary: ${theme.tokens.textSecondary};`,
    '}',
    '',
    '.vinyl-page {',
    `  background: ${theme.tokens.backgroundGradient};`,
    '  color: var(--vinyl-text-primary);',
    '}',
  ].join('\n');
}

export function createBlackVinylThemeFromHsl(input) {
  if (!input || ![input.h, input.s, input.l].every(Number.isFinite)) {
    throw new Error('Input must include finite h, s, and l numbers.');
  }

  const h = round((((input.h % 360) + 360) % 360));
  const rawS = clamp(round(input.s), 0, 100);
  const rawL = clamp(round(input.l), 0, 100);
  const baseHex = normalizeHex(input.hex) || colorToken(h, rawS, rawL).hex;
  const sat = saturationRule(rawL);
  const bg = backgroundLightnessRule(rawL);
  const nextS = adjustedS(rawS, sat);
  const topL = clamp(round(bg.topL), 0, 100);
  const bottomL = clamp(round(bg.bottomL), 0, 100);
  const buttonL = clamp(round(Math.max(topL, bottomL) + 42), 70, 92);
  const top = colorToken(h, nextS, topL);
  const bottom = colorToken(h, nextS, bottomL);
  const button = colorToken(h, clamp(nextS + 8, 0, 100), buttonL);
  const gradientCss = `linear-gradient(180deg, ${top.hex} 0%, ${bottom.hex} 100%)`;

  const theme = {
    skillCode: SKILL_CODE,
    version: VERSION,
    source: input.source || 'HSL input',
    range: sat.range,
    base: {
      hex: baseHex,
      h,
      s: rawS,
      l: rawL,
    },
    adjusted: {
      s: nextS,
      topL,
      bottomL,
      saturationDivisor: Number(sat.divisor.toFixed(3)),
      saturationFormula: sat.formula,
      topLightnessFormula: bg.topFormula,
      bottomLightnessFormula: bg.bottomFormula,
    },
    gradient: {
      angle: '180deg',
      top,
      bottom,
      css: gradientCss,
    },
    tokens: {
      bgTop: top.hex,
      bgBottom: bottom.hex,
      bgTopHsl: top.hsl,
      bgBottomHsl: bottom.hsl,
      backgroundGradient: gradientCss,
      accent: baseHex,
      buttonFill: button.hex,
      buttonFillHsl: button.hsl,
      buttonText: 'hsla(10, 74%, 49%, 1)',
      textPrimary: '#ffffff',
      textSecondary: 'rgba(255, 255, 255, 0.68)',
    },
    figmaPaint: createFigmaPaint(top.hex, bottom.hex),
    explanation: [
      `基准色取自 ${input.source || 'HSL input'}：${baseHex}，H=${h}、S=${rawS}、L=${rawL}。`,
      `H 保持不变，命中 ${sat.range} 区间，S 倍数=${Number(sat.divisor.toFixed(3))}，${sat.formula}，新 S=${nextS}。${sat.note}`,
      `${bg.note} ${bg.topFormula}；${bg.bottomFormula}。新顶部 L=${topL}，新底部 L=${bottomL}。`,
      'S 与 L 均已四舍五入，并限制在 0-100 范围内，方便直接落到 CSS / Figma token。',
    ],
  };

  return {
    ...theme,
    css: cssText(theme),
  };
}

function swatchToHslInput(swatch, source) {
  if (!swatch) return null;
  if (typeof swatch === 'string') {
    const hex = normalizeHex(swatch);
    return hex ? { ...hexToHsl(hex), source } : null;
  }
  const hex = normalizeHex(swatch.hex || swatch.color || swatch.dominantColorHex || swatch.googleDominatColorHex);
  if (swatch.hsl && Number.isFinite(swatch.hsl.h) && Number.isFinite(swatch.hsl.s) && Number.isFinite(swatch.hsl.l)) {
    return { hex: hex || undefined, h: swatch.hsl.h, s: swatch.hsl.s, l: swatch.hsl.l, source };
  }
  if (Number.isFinite(swatch.h) && Number.isFinite(swatch.s) && Number.isFinite(swatch.l)) {
    return { hex: hex || undefined, h: swatch.h, s: swatch.s, l: swatch.l, source };
  }
  if (hex) {
    return { ...hexToHsl(hex), source };
  }
  return null;
}

function pickSource(input) {
  if (!input || typeof input !== 'object') return null;

  const directHex = normalizeHex(input.dominantColor || input.hex || input.color);
  if (directHex) return { ...hexToHsl(directHex), source: 'dominantColor' };

  const serviceHex = normalizeHex(input.main?.dominantColorHex || input.main?.googleDominatColorHex);
  if (serviceHex) return { ...hexToHsl(serviceHex), source: 'main.dominantColorHex' };

  if ([input.h, input.s, input.l].every(Number.isFinite)) {
    return { h: input.h, s: input.s, l: input.l, hex: normalizeHex(input.hex) || undefined, source: input.source || 'HSL input' };
  }

  const result = input.pickerResult || input.result || input;
  const candidates = [
    ['D.no_filter', result.D?.no_filter],
    ['D.with_filter', result.D?.with_filter],
    ['D.no_filter', result.dominate?.no_filter],
    ['D.with_filter', result.dominate?.with_filter],
    ['palette_16[0]', result.palette_16?.[0]],
  ];

  for (const [source, swatch] of candidates) {
    const picked = swatchToHslInput(swatch, source);
    if (picked) return picked;
  }

  return null;
}

export function createBlackVinylTheme(input) {
  const picked = typeof input === 'string' ? parseColorString(input) : pickSource(input);
  if (!picked) {
    throw new Error('Cannot find a valid color. Pass #RRGGBB, HSL, dominantColor, D.no_filter, D.with_filter, palette_16[0], or main.dominantColorHex.');
  }
  return createBlackVinylThemeFromHsl(picked);
}

function parseColorString(raw) {
  const text = raw.trim();
  const hex = normalizeHex(text);
  if (hex) return { ...hexToHsl(hex), source: 'color string' };

  const hslFn = text.match(/^hsla?\(\s*(-?\d+(?:\.\d+)?)(?:deg)?[\s,]+(\d+(?:\.\d+)?)%?[\s,]+(\d+(?:\.\d+)?)%?(?:\s*[/,]\s*[\d.]+%?)?\s*\)$/i);
  if (hslFn) {
    return {
      h: Number(hslFn[1]),
      s: Number(hslFn[2]),
      l: Number(hslFn[3]),
      source: 'HSL string',
    };
  }

  const labeled = text.match(/^h\s*[:=]?\s*(-?\d+(?:\.\d+)?)\D+s\s*[:=]?\s*(\d+(?:\.\d+)?)%?\D+l\s*[:=]?\s*(\d+(?:\.\d+)?)%?$/i);
  if (labeled) {
    return {
      h: Number(labeled[1]),
      s: Number(labeled[2]),
      l: Number(labeled[3]),
      source: 'HSL string',
    };
  }

  const triplet = text.match(/^\s*(-?\d+(?:\.\d+)?)\s*[,，\s]\s*(\d+(?:\.\d+)?)%?\s*[,，\s]\s*(\d+(?:\.\d+)?)%?\s*$/);
  if (triplet) {
    return {
      h: Number(triplet[1]),
      s: Number(triplet[2]),
      l: Number(triplet[3]),
      source: 'HSL string',
    };
  }

  return null;
}

async function readStdin() {
  if (process.stdin.isTTY) return '';
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  return Buffer.concat(chunks).toString('utf8').trim();
}

async function main() {
  const argvInput = process.argv.slice(2).join(' ').trim();
  const stdinInput = await readStdin();
  const raw = argvInput || stdinInput;
  if (!raw) {
    console.error('Usage: node scripts/black-vinyl-theme.mjs "#4C4C4D"');
    console.error('   or: echo \'{"dominantColor":"#4C4C4D"}\' | node scripts/black-vinyl-theme.mjs');
    process.exit(1);
  }

  let input = raw;
  if (/^\s*[\[{]/.test(raw)) {
    input = JSON.parse(raw);
  }

  const result = createBlackVinylTheme(input);
  console.log(JSON.stringify(result, null, 2));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(error.message || String(error));
    process.exit(1);
  });
}
