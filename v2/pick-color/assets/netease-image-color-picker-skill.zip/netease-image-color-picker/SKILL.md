---
name: netease-image-color-picker
description: Call the NetEase Cloud Music color picking website capability for image palette extraction. Use when a user asks to extract image colors through the website, invoke the website color service, process image URL/upload/pasted images, get D/T/B/L/R dominant colors, filtered black-white colors, or return a compact DTBLR JSON result for designers, developers, AI workflows, or Figma/plugin integrations.
---

# NetEase Image Color Picker

## Overview

Use this skill to call the website color-picking capability as a shared service. It standardizes how different people use the same capability: designers use the web UI, developers call the API/script, and AI workflows consume the compact DTBLR JSON result.

## Capability Boundary

- URL input: call the website/AIO URL extraction path first.
- Upload, drag, and pasted image body: use the website UI, where the browser Canvas path can read local bytes.
- External URL that cannot be read by the service or browser: ask the user to copy the image body and paste with Cmd+V, or download then upload.
- Do not invent color values. Return the website result or a clear failure reason.

## Quick Start

Open the website for human use:

```text
https://cms.qa.igame.163.com/g/pick-color/
```

Call URL extraction from a script:

```bash
node scripts/extract-url.mjs 'http://p2.music.126.net/TLaWmMvoLmiOC27ce8B2fg==/807041534787715.jpg'
```

Use another deployed host:

```bash
PICK_COLOR_ORIGIN='https://cms.qa.igame.163.com' node scripts/extract-url.mjs 'http://p2.music.126.net/TLaWmMvoLmiOC27ce8B2fg==/807041534787715.jpg'
```

## Workflow

1. Receive an image source.
2. If it is an HTTP/HTTPS URL, call the website extraction endpoint through `scripts/extract-url.mjs`.
3. If it is a local file, screenshot, copied image body, or drag/upload image, direct the user to the website UI because browser-local bytes are required.
4. Return only the compact DTBLR fields by default:
   - `D/T/B/L/R.no_filter`
   - `D/T/B/L/R.with_filter`
5. Use `node scripts/extract-url.mjs --full URL` only when debugging needs the full website JSON.

## Output Rules

Return compact machine-readable JSON by default:

```json
{
  "D": { "no_filter": "#xxxxxx", "with_filter": "#xxxxxx" },
  "T": { "no_filter": "#xxxxxx", "with_filter": "#xxxxxx" },
  "B": { "no_filter": "#xxxxxx", "with_filter": "#xxxxxx" },
  "L": { "no_filter": "#xxxxxx", "with_filter": "#xxxxxx" },
  "R": { "no_filter": "#xxxxxx", "with_filter": "#xxxxxx" }
}
```

## References

- Read `references/io-schema.json` for the output contract.
- Read `references/usage-by-role.md` when explaining usage to designers, developers, AI workflow owners, or plugin developers.
