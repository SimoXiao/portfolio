# Usage By Role

## Designers

Use the website directly. Paste an image URL, upload a file, drag an image, or paste an image body with Cmd+V. Copy D/T/B/L/R colors and filtered colors from the result page.

## Developers

Use `scripts/extract-url.mjs` for URL-based extraction and consume the compact DTBLR JSON. For local files, use the website UI unless a server-side upload/NOS path is available.

## AI Workflow Owners

Call this skill first to get structured color data, then pass `D.no_filter` to downstream business skills such as black vinyl page theme generation.

## Plugin Developers

Use the unified JSON as plugin input. For Figma plugins, convert selected fields into fills, variables, gradients, or inspectable design tokens.
