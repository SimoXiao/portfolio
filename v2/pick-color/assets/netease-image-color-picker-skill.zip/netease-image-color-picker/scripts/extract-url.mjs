#!/usr/bin/env node

const DEFAULT_ORIGIN = 'https://cms.qa.igame.163.com';
const ENDPOINT_PATH = '/g/pick-color/api/aio/extract';
const SAMPLE_URL = 'http://p2.music.126.net/TLaWmMvoLmiOC27ce8B2fg==/807041534787715.jpg';

function usage() {
  console.error(`Usage: node scripts/extract-url.mjs "${SAMPLE_URL}"`);
  console.error(`Full result: node scripts/extract-url.mjs --full "${SAMPLE_URL}"`);
  console.error('Optional: PICK_COLOR_ORIGIN="https://cms.qa.igame.163.com" node scripts/extract-url.mjs URL');
}

function assertUrl(value) {
  try {
    const u = new URL(value);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('not http');
    if (u.hostname.includes('example.') || /example\.(jpg|jpeg|png|webp|gif)$/i.test(u.pathname)) {
      throw new Error(`This is a placeholder URL. Replace it with a real image URL, for example: ${SAMPLE_URL}`);
    }
    return u.toString();
  } catch (error) {
    if (error?.message?.includes('placeholder URL')) throw error;
    throw new Error('Input must be a real http/https image URL. For local files or pasted images, use the website UI.');
  }
}

function envelopeMessage(payload, fallback) {
  const msg = payload?.message || payload?.msg;
  if (msg) {
    const code = payload?.code !== undefined ? ` [${payload.code}]` : '';
    return `${msg}${code}`;
  }
  return fallback;
}

async function extractUrl(imageUrl, origin = DEFAULT_ORIGIN) {
  const endpoint = new URL(ENDPOINT_PATH, origin).toString();
  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageUrl }),
  });

  let payload = null;
  try {
    payload = await resp.json();
  } catch {
    throw new Error(`Color picking endpoint returned non-JSON response: HTTP ${resp.status}`);
  }

  if (!resp.ok) {
    throw new Error(envelopeMessage(payload, `Color picking endpoint failed: HTTP ${resp.status}`));
  }
  if (payload?.code !== 200 || !payload?.data) {
    throw new Error(envelopeMessage(payload, `Unexpected color picking envelope: ${JSON.stringify(payload).slice(0, 200)}`));
  }

  return {
    skillCode: 'NETEASE_IMAGE_COLOR_PICKER',
    version: '0.1.0',
    input: { imageUrl },
    data: payload.data,
  };
}

function hexOnly(swatch) {
  return swatch?.hex || null;
}

function toDtblr(result) {
  const regions = result?.data?.regions || {};
  const pick = (key) => ({
    no_filter: hexOnly(regions[key]?.no_filter),
    with_filter: hexOnly(regions[key]?.with_filter),
  });
  return {
    D: pick('D'),
    T: pick('T'),
    B: pick('B'),
    L: pick('L'),
    R: pick('R'),
  };
}

async function main() {
  const args = process.argv.slice(2);
  const full = args.includes('--full');
  const raw = args.filter((arg) => arg !== '--full').join(' ').trim();
  if (!raw) {
    usage();
    process.exit(1);
  }
  const imageUrl = assertUrl(raw);
  const result = await extractUrl(imageUrl, process.env.PICK_COLOR_ORIGIN || DEFAULT_ORIGIN);
  console.log(JSON.stringify(full ? result : toDtblr(result), null, 2));
}

main().catch((error) => {
  console.error(error.message || String(error));
  process.exit(1);
});
